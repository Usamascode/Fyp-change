import { Role } from '@prisma/client';

const allRoles = {
  [Role.USER]: ['getOrders'],
  [Role.ADMIN]: ['getUsers', 'manageUsers', 'getOrders', 'manageOrders'],
  [Role.FARMER]: ['manageProducts', 'getOrders', 'manageOrders']
};

export const roles = Object.keys(allRoles);
export const roleRights = new Map(Object.entries(allRoles));
