import express from 'express';
import auth from '../../middlewares/auth';
import validate from '../../middlewares/validate';
import productValidation from '../../validations/product.validation';
import productController from '../../controllers/product.controller';
import { upload } from '../../utils/fileUpload';

const router = express.Router();

router
  .route('/')
  .post(
    auth('manageProducts'),
    upload.single('image'),
    validate(productValidation.createProduct),
    productController.createProduct
  )
  .get(validate(productValidation.getProducts), productController.getProducts);

router
  .route('/farmer')
  .get(
    auth('manageProducts'),
    validate(productValidation.getProducts),
    productController.getFarmerProducts
  );

router
  .route('/:slug')
  .get(validate(productValidation.getProduct), productController.getProduct)
  .patch(
    auth('manageProducts'),
    upload.single('image'),
    validate(productValidation.updateProduct),
    productController.updateProduct
  )
  .delete(
    auth('manageProducts'),
    validate(productValidation.getProduct),
    productController.deleteProduct
  );

export default router;
