import express from 'express';
import auth from '../../middlewares/auth';
import validate from '../../middlewares/validate';
import orderValidation from '../../validations/order.validation';
import orderController from '../../controllers/order.controller';

const router = express.Router();

router
  .route('/')
  .post(auth(), validate(orderValidation.createOrder), orderController.createOrder)
  .get(auth(), validate(orderValidation.getOrders), orderController.getOrders);

router
  .route('/:orderId')
  .get(auth(), validate(orderValidation.getOrder), orderController.getOrder)
  .patch(
    auth('manageOrders'),
    validate(orderValidation.updateOrderStatus),
    orderController.updateOrderStatus
  );

export default router;
