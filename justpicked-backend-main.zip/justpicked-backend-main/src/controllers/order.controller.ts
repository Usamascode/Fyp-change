import httpStatus from 'http-status';
import pick from '../utils/pick';
import ApiError from '../utils/ApiError';
import catchAsync from '../utils/catchAsync';
import { orderService } from '../services';
import { User } from '@prisma/client';

const createOrder = catchAsync(async (req, res) => {
  const user = req.user as User;
  const order = await orderService.createOrder(req.body, user.id);
  res.status(httpStatus.CREATED).send(order);
});

const getOrders = catchAsync(async (req, res) => {
  const user = req.user as User;
  const filter = pick(req.query, ['status']);
  const options = pick(req.query, ['sortBy', 'sortType', 'limit', 'page']);

  // Filter orders based on user role
  if (user.role === 'FARMER') {
    filter.farmerId = user.id;
  } else {
    filter.userId = user.id;
  }

  const result = await orderService.queryOrders(filter, options);
  res.send(result);
});

const getOrder = catchAsync(async (req, res) => {
  const user = req.user as User;
  const order = await orderService.getOrderById(req.params.orderId);
  if (!order) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Order not found');
  }

  // Check if user has permission to view the order
  if (user.role !== 'ADMIN' && order.userId !== user.id && order.farmerId !== user.id) {
    throw new ApiError(httpStatus.FORBIDDEN, 'You can only view your own orders');
  }

  res.send(order);
});

const updateOrderStatus = catchAsync(async (req, res) => {
  const user = req.user as User;
  const order = await orderService.getOrderById(req.params.orderId);
  if (!order) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Order not found');
  }

  // Only farmer can update order status
  if (user.role !== 'FARMER' || order.farmerId !== user.id) {
    throw new ApiError(httpStatus.FORBIDDEN, 'Only the farmer can update order status');
  }

  const updatedOrder = await orderService.updateOrderStatus(order.id, req.body.status);
  res.send(updatedOrder);
});

export default {
  createOrder,
  getOrders,
  getOrder,
  updateOrderStatus
}; 