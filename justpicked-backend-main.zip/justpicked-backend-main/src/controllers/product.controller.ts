import httpStatus from 'http-status';
import pick from '../utils/pick';
import ApiError from '../utils/ApiError';
import catchAsync from '../utils/catchAsync';
import { productService } from '../services';
import { User, Product, Role } from '@prisma/client';
import { deleteFile } from '../utils/fileUpload';
import { Request } from 'express';
import slugify from 'slugify';

interface RequestWithFile extends Request {
  file?: Express.Multer.File;
}

const createProduct = catchAsync(async (req: RequestWithFile, res) => {
  const user = req.user as User;
  if (user.role !== 'FARMER') {
    throw new ApiError(httpStatus.FORBIDDEN, 'Only farmers can create products');
  }

  if (!req.file) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Product image is required');
  }

  const product = await productService.createProduct(
    {
      name: req.body.name,
      description: req.body.description,
      price: req.body.price,
      imageUrl: req.file.path,
      stock: req.body.stock,
      category: req.body.category
    },
    user.id
  );
  res.status(httpStatus.CREATED).send(product);
});

const getFarmerProducts = catchAsync(async (req: any, res) => {
  const filter = pick(req.query, ['name', 'minPrice', 'maxPrice']);
  const options = pick(req.query, ['sortBy', 'sortType', 'limit', 'page']);

  // Build price range filter
  if (filter.minPrice || filter.maxPrice) {
    filter.price = {
      gte: filter.minPrice,
      lte: filter.maxPrice
    };
    delete filter.minPrice;
    delete filter.maxPrice;
  }
  if (req.user?.role === Role.FARMER) {
    filter.farmerId = req.user.id;
  }

  const result = await productService.queryProducts(filter, options);
  res.send(result);
});

const getProducts = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'minPrice', 'maxPrice']);
  const options = pick(req.query, ['sortBy', 'sortType', 'limit', 'page']);

  // Build price range filter
  if (filter.minPrice || filter.maxPrice) {
    filter.price = {
      gte: filter.minPrice,
      lte: filter.maxPrice
    };
    delete filter.minPrice;
    delete filter.maxPrice;
  }

  const result = await productService.queryProducts(filter, options);
  res.send(result);
});

const getProduct = catchAsync(async (req, res) => {
  const product = await productService.getProductBySlug(req.params.slug);
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }
  res.send(product);
});

const updateProduct = catchAsync(async (req: RequestWithFile, res) => {
  const user = req.user as User;
  const product = await productService.getProductBySlug(req.params.slug);
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }
  if (product.farmerId !== user.id && user.role !== 'ADMIN') {
    throw new ApiError(httpStatus.FORBIDDEN, 'You can only update your own products');
  }

  let imageUrl = (product as Product & { imageUrl?: string }).imageUrl;
  if (req.file) {
    // Delete old image if exists
    if ((product as Product & { imageUrl?: string }).imageUrl) {
      const oldFilename = (product as Product & { imageUrl?: string }).imageUrl?.split('/').pop();
      if (oldFilename) deleteFile(oldFilename);
    }
    imageUrl = req.file.path;
  }

  const updatedProduct = await productService.updateProductById(product.id, {
    name: req.body.name,
    description: req.body.description,
    price: req.body.price,
    imageUrl,
    stock: req.body.stock,
    category: req.body.category,
    slug: slugify(req.body.name)
  });
  res.send(updatedProduct);
});

const deleteProduct = catchAsync(async (req, res) => {
  const user = req.user as User;
  const product = await productService.getProductBySlug(req.params.slug);
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }
  if (product.farmerId !== user.id && user.role !== 'ADMIN') {
    throw new ApiError(httpStatus.FORBIDDEN, 'You can only delete your own products');
  }

  // Delete product image if exists
  if ((product as Product & { imageUrl?: string }).imageUrl) {
    const filename = (product as Product & { imageUrl?: string }).imageUrl?.split('/').pop();
    if (filename) deleteFile(filename);
  }

  await productService.deleteProductById(product.id);
  res.status(httpStatus.NO_CONTENT).send();
});

export default {
  createProduct,
  getProducts,
  getProduct,
  updateProduct,
  deleteProduct,
  getFarmerProducts
};
