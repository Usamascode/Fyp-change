import { Order, OrderStatus, Product, User } from '@prisma/client';
import httpStatus from 'http-status';
import prisma from '../client';
import ApiError from '../utils/ApiError';

/**
 * Create an order
 * @param {Object} orderBody
 * @param {string} userId
 * @returns {Promise<Order>}
 */
const createOrder = async (
  orderBody: { productId: string; quantity: number },
  userId: string
): Promise<Order> => {
  const product = await prisma.product.findUnique({
    where: { id: orderBody.productId }
  });
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }
  if (product?.stock < orderBody?.quantity) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Stock out');
  }

  const totalPrice = (Number(product.price) * orderBody.quantity).toString();
  const updatedQuantity = Number(product?.stock) - orderBody?.quantity;
  await prisma.product.update({
    where: {
      id: orderBody?.productId
    },
    data: {
      stock: updatedQuantity
    }
  });

  return prisma.order.create({
    data: {
      ...orderBody,
      totalPrice,
      userId,
      farmerId: product.farmerId
    },
    include: {
      product: true,
      user: {
        select: {
          id: true,
          name: true
        }
      }
    }
  });
};

/**
 * Query for orders
 * @param {Object} filter - Prisma filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryOrders = async (
  filter: object,
  options: {
    limit?: number;
    page?: number;
    sortBy?: string;
    sortType?: 'asc' | 'desc';
  }
): Promise<{ orders: Order[]; total: number }> => {
  const page = options.page ?? 1;
  const limit = options.limit ?? 10;
  const sortBy = options.sortBy;
  const sortType = options.sortType ?? 'desc';

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where: filter,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: sortBy ? { [sortBy]: sortType } : undefined,
      include: {
        product: true,
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        }
      }
    }),
    prisma.order.count({ where: filter })
  ]);

  return { orders, total };
};

/**
 * Get order by id
 * @param {string} orderId
 * @returns {Promise<Order | null>}
 */
const getOrderById = async (orderId: string): Promise<Order | null> => {
  return prisma.order.findUnique({
    where: { id: orderId },
    include: {
      product: true,
      user: {
        select: {
          id: true,
          name: true
        }
      }
    }
  });
};

/**
 * Update order status
 * @param {string} orderId
 * @param {OrderStatus} status
 * @returns {Promise<Order>}
 */
const updateOrderStatus = async (orderId: string, status: OrderStatus): Promise<Order> => {
  const order = await prisma.order.findUnique({
    where: { id: orderId }
  });
  if (!order) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Order not found');
  }

  return prisma.order.update({
    where: { id: orderId },
    data: { status },
    include: {
      product: true,
      user: {
        select: {
          id: true,
          name: true
        }
      }
    }
  });
};

export default {
  createOrder,
  queryOrders,
  getOrderById,
  updateOrderStatus
};
