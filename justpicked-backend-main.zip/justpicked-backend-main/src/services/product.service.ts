import { Product } from '@prisma/client';
import httpStatus from 'http-status';
import prisma from '../client';
import ApiError from '../utils/ApiError';
import slugify from 'slugify';

/**
 * Create a product
 * @param {Object} productBody
 * @param {string} farmerId
 * @returns {Promise<Product>}
 */
const createProduct = async (
  productBody: Omit<Product, 'id' | 'slug' | 'farmerId' | 'createdAt' | 'updatedAt'>,
  farmerId: string
): Promise<Product> => {
  const slug = slugify(productBody.name, { lower: true });
  return prisma.product.create({
    data: {
      ...productBody,
      slug,
      farmerId
    }
  });
};

/**
 * Query for products
 * @param {Object} filter - Prisma filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryProducts = async (
  filter: object,
  options: {
    limit?: number;
    page?: number;
    sortBy?: string;
    sortType?: 'asc' | 'desc';
  }
): Promise<{ products: Product[]; total: number; totalPages: number }> => {
  const page = options.page ?? 1;
  const limit = options.limit ?? 10;
  const sortBy = options.sortBy;
  const sortType = options.sortType ?? 'desc';

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where: filter,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: sortBy ? { [sortBy]: sortType } : undefined,
      include: {
        farmer: {
          select: {
            id: true,
            name: true
          }
        }
      }
    }),
    prisma.product.count({ where: filter })
  ]);

  return { products, total, totalPages: Math.ceil(total / limit) };
};

/**
 * Get product by slug
 * @param {string} slug
 * @returns {Promise<Product | null>}
 */
const getProductBySlug = async (slug: string): Promise<Product | null> => {
  return prisma.product.findUnique({
    where: { slug },
    include: {
      farmer: {
        select: {
          id: true,
          name: true
        }
      }
    }
  });
};

/**
 * Update product by id
 * @param {string} productId
 * @param {Object} updateBody
 * @returns {Promise<Product>}
 */
const updateProductById = async (
  productId: string,
  updateBody: Omit<Product, 'id' | 'farmerId' | 'createdAt' | 'updatedAt'>
): Promise<Product> => {
  const product = await prisma.product.findUnique({
    where: { id: productId }
  });
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }

  if (updateBody.name) {
    updateBody.slug = slugify(updateBody.name, { lower: true });
  }

  return prisma.product.update({
    where: { id: productId },
    data: updateBody
  });
};

/**
 * Delete product by id
 * @param {string} productId
 * @returns {Promise<Product>}
 */
const deleteProductById = async (productId: string): Promise<Product> => {
  const product = await prisma.product.findUnique({
    where: { id: productId }
  });
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }
  return prisma.product.delete({
    where: { id: productId }
  });
};

export default {
  createProduct,
  queryProducts,
  getProductBySlug,
  updateProductById,
  deleteProductById
};
