import Joi from 'joi';
import { Role } from '@prisma/client';

const createProduct = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    description: Joi.string(),
    price: Joi.string().required(),
    image: Joi.any(),
    stock: Joi.number().required(),
    category: Joi.string().required()
  })
};

const updateProduct = {
  params: Joi.object().keys({
    slug: Joi.string().required()
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      description: Joi.string(),
      price: Joi.string(),
      image: Joi.any(),
      stock: Joi.number(),
      category: Joi.string()
    })
    .min(1)
};

const getProduct = {
  params: Joi.object().keys({
    slug: Joi.string().required()
  })
};

const getProducts = {
  query: Joi.object().keys({
    name: Joi.string(),
    minPrice: Joi.string(),
    maxPrice: Joi.string(),
    inStock: Joi.boolean(),
    sortBy: Joi.string(),
    sortType: Joi.string().valid('asc', 'desc'),
    limit: Joi.number().integer().min(1),
    page: Joi.number().integer().min(1)
  })
};

export default {
  createProduct,
  updateProduct,
  getProduct,
  getProducts
};
