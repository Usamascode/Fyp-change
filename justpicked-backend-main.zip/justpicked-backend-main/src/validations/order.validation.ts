import Joi from 'joi';

const createOrder = {
  body: Joi.object().keys({
    productId: Joi.string().required(),
    quantity: Joi.number().required().min(1)
  })
};

const updateOrderStatus = {
  params: Joi.object().keys({
    orderId: Joi.string().required()
  }),
  body: Joi.object().keys({
    status: Joi.string().valid('CONFIRMED', 'CANCELLED', 'DELIVERED').required()
  })
};

const getOrders = {
  query: Joi.object().keys({
    status: Joi.string().valid('PENDING', 'CONFIRMED', 'CANCELLED', 'DELIVERED'),
    sortBy: Joi.string(),
    sortType: Joi.string().valid('asc', 'desc'),
    limit: Joi.number().integer().min(1),
    page: Joi.number().integer().min(1)
  })
};

const getOrder = {
  params: Joi.object().keys({
    orderId: Joi.string().required()
  })
};

export default {
  createOrder,
  updateOrderStatus,
  getOrders,
  getOrder
}; 