import { Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import LandingPage from "pages/LandingPage";
import LoginPage from "pages/LoginPage";
import RegisterCustomerPage from "pages/RegisterCustomerPage";
import RegisterFarmerPage from "pages/RegisterFarmerPage";
import ProductDetailPage from "pages/ProductDetailPage";
import OrdersPage from "pages/OrdersPage";
import FarmerDashboardPage from "pages/farmer/DashboardPage";
import FarmerProductsPage from "pages/farmer/ProductsPage";
import FarmerOrdersPage from "pages/farmer/OrdersPage";
import CreateProductPage from "pages/farmer/CreateProductPage";

import PrivateRoute from "components/privateRoute";
import PrivateFarmerRoute from "components/privateFarmerRoute";
import PublicRoute from "components/publicRoute";
import FarmerLayout from "layouts/FarmerLayout";
import Navbar from "components/Navbar";

const App = () => {
  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
      <Navbar />
      <div className="pt-14">
        <Routes>
          {/* <Route element={<PublicRoute />}> */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route
              path="/register/customer"
              element={<RegisterCustomerPage />}
            />
            <Route path="/register/farmer" element={<RegisterFarmerPage />} />
          {/* </Route> */}

          <Route element={<PrivateRoute />}>
            <Route
              path="/products/:productId"
              element={<ProductDetailPage />}
            />
            <Route path="/orders" element={<OrdersPage />} />
          </Route>

          {/* Farmer Routes */}
          <Route element={<PrivateFarmerRoute />}>
            <Route path="/farmer" element={<FarmerLayout />}>
              <Route index element={<FarmerDashboardPage />} />
              <Route path="products" element={<FarmerProductsPage />} />
              <Route path="products/create" element={<CreateProductPage />} />
              <Route path="orders" element={<FarmerOrdersPage />} />
            </Route>
          </Route>
        </Routes>
      </div>
    </>
  );
};

export default App;
