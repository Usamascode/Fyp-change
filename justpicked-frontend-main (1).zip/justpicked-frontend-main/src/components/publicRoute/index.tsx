// PublicRoute.tsx
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from 'stores/authStore';

interface PublicRouteProps {
    redirectPath?: string;
}

const PublicRoute: React.FC<PublicRouteProps> = ({ redirectPath = '/' }) => {
    const isAuthenticated = useAuthStore((state) => state.isAuthenticated);

    return !isAuthenticated ? <Outlet /> : <Navigate to={redirectPath} />;
};

export default PublicRoute;
