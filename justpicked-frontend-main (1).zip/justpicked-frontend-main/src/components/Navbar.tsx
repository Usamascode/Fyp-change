import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuthStore } from "stores/authStore";
import { FaShoppingCart, FaUser, FaSignOutAlt } from "react-icons/fa";
import { PiPlantFill } from "react-icons/pi";
import { RiMenu3Fill } from "react-icons/ri";
import { AiOutlineClose } from "react-icons/ai";

const Navbar = () => {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAuthenticated, user, logout } = useAuthStore();

  const handleLogout = () => {
    logout();
    setMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header
      className={`fixed top-0 z-50 ${
        isMobileMenuOpen ? "h-full" : ""
      } w-full bg-zinc-50/80 backdrop-blur-3xl sm:h-auto`}
    >
      <div className=" flex h-full w-full flex-wrap gap-10 px-4 py-3.5 sm:mx-auto sm:h-auto sm:max-w-7xl sm:items-center sm:justify-between">
        <div className="flex h-max w-full sm:w-max items-center justify-between">
          <div className="flex h-max items-center gap-2 sm:h-auto">
            <PiPlantFill className="h-8 w-8 text-green-500" />
            <button className="text-2xl font-bold text-gray-800">
              JustPicked
            </button>
          </div>
          <button className="flex sm:hidden" onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? (
              <AiOutlineClose className="h-6 w-6 text-zinc-950" />
            ) : (
              <RiMenu3Fill className="h-6 w-6 text-zinc-950" />
            )}
          </button>
        </div>

        <div
          className={`sm:flex ${
            isMobileMenuOpen ? "flex" : "hidden"
          } h-full w-full flex-col items-center justify-center gap-6 sm:h-auto sm:w-auto sm:flex-row sm:flex-wrap sm:gap-0 sm:rounded-full sm:border sm:backdrop-blur-xl`}
        >
          {isAuthenticated ? (
            <>
              {user?.role === "USER" && (
                <Link
                  to="/orders"
                  onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
                  className="flex h-max w-full items-center gap-2 rounded-full px-4 py-1 text-zinc-500 transition hover:bg-green-50 sm:h-auto sm:w-max"
                >
                  <FaShoppingCart />
                  <span>My Orders</span>
                </Link>
              )}

              {user?.role === "FARMER" && (
                <Link
                  to="/farmer"
                  onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
                  className="flex h-max w-full items-center gap-2 rounded-full px-4 py-1 text-zinc-500 transition hover:bg-green-50 sm:h-auto sm:w-max"
                >
                  <FaUser />
                  <span>Farmer Dashboard</span>
                </Link>
              )}

              <button
                onClick={handleLogout}
                className="flex h-max w-full items-center gap-2 rounded-full px-4 py-1 text-zinc-900 transition hover:bg-green-600 sm:h-auto sm:w-max"
              >
                <FaSignOutAlt />
                <span>Logout</span>
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
                className="h-max w-full rounded-full px-6 py-2 font-semibold text-zinc-900 transition hover:bg-green-600 sm:h-auto sm:w-max"
              >
                Login
              </Link>
              <div className="flex flex-wrap">
                <Link
                  to="/register/farmer"
                  onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
                  className="h-max w-full rounded-full px-6 py-2 text-zinc-500 transition hover:bg-zinc-100 sm:h-auto sm:w-max"
                >
                  Register as Farmer
                </Link>
                <Link
                  to="/register/customer"
                  onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
                  className="h-max w-full rounded-full px-6 py-2 text-zinc-500 transition hover:bg-green-50 sm:h-auto sm:w-max"
                >
                  Register as Customer
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
