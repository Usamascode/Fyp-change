// PrivateFarmerRoute.tsx
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from 'stores/authStore';

interface PrivateFarmerRouteProps {
  redirectPath?: string;
}

const PrivateFarmerRoute: React.FC<PrivateFarmerRouteProps> = ({ redirectPath = '/login' }) => {
  const authStore = useAuthStore((state) => state);
  const isAuthenticated = authStore.isAuthenticated && authStore.user.role === 'FARMER';

  return isAuthenticated ? <Outlet /> : <Navigate to={redirectPath} />;
};

export default PrivateFarmerRoute;
