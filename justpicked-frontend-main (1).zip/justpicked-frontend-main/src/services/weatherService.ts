import axios from 'axios';

const OPENWEATHER_API_KEY = '200f8e97e29818bc9dc33e70f61be78d';
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

export interface WeatherData {
  currentWeather: {
    temperature: number;
    condition: string;
    humidity: number;
    windSpeed: number;
    feelsLike: number;
  };
  forecast: {
    date: string;
    temperature: number;
    condition: string;
    humidity: number;
    windSpeed: number;
  }[];
  location: string;
}

export const getWeatherByLocation = async (lat: number, lon: number): Promise<WeatherData> => {
  try {
    // Get current weather
    const currentWeatherResponse = await axios.get(`${BASE_URL}/weather`, {
      params: {
        lat,
        lon,
        appid: OPENWEATHER_API_KEY,
        units: 'metric',
      },
    });

    // Get 5-day forecast
    const forecastResponse = await axios.get(`${BASE_URL}/forecast`, {
      params: {
        lat,
        lon,
        appid: OPENWEATHER_API_KEY,
        units: 'metric',
      },
    });

    // Process current weather
    const currentWeather = {
      temperature: Math.round(currentWeatherResponse.data.main.temp),
      condition: currentWeatherResponse.data.weather[0].main,
      humidity: currentWeatherResponse.data.main.humidity,
      windSpeed: Math.round(currentWeatherResponse.data.wind.speed),
      feelsLike: Math.round(currentWeatherResponse.data.main.feels_like),
    };

    // Process forecast data (get one forecast per day)
    const dailyForecasts = forecastResponse.data.list.filter((item: any, index: number) => index % 8 === 0);
    const forecast = dailyForecasts.map((item: any) => ({
      date: new Date(item.dt * 1000).toLocaleDateString('en-US', { weekday: 'short' }),
      temperature: Math.round(item.main.temp),
      condition: item.weather[0].main,
      humidity: item.main.humidity,
      windSpeed: Math.round(item.wind.speed),
    }));

    return {
      currentWeather,
      forecast: forecast.slice(0, 5), // Get only 5 days
      location: currentWeatherResponse.data.name,
    };
  } catch (error) {
    console.error('Error fetching weather data:', error);
    throw error;
  }
};

export const getUserLocation = (): Promise<{ lat: number; lon: number }> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          lat: position.coords.latitude,
          lon: position.coords.longitude,
        });
      },
      (error) => {
        reject(error);
      }
    );
  });
}; 