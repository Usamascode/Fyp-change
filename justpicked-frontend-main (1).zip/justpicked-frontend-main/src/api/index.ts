import { auth } from "./auth";
import { inventory } from "./inventory";
import { products } from "./product";

export const api = {
  auth,
  inventory,
  products,
};
