import axiosInstance from "config/axiosInstance";

export type OrderStatus = "PENDING" | "CONFIRMED" | "CANCELLED" | "DELIVERED";

export interface Order {
  id: string;
  userId: string;
  farmerId: string;
  productId: string;
  quantity: number;
  totalPrice: string;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
  product: {
    id: string;
    name: string;
    imageUrl: string;
    price: string;
  };
  user: {
    phone: string;
    id: string;
    name: string;
    email: string;
  };
}

export interface OrderItem {
  id: string;
  productId: string;
  quantity: number;
  price: string;
  product: {
    id: string;
    name: string;
    image: string;
  };
}

export interface CreateOrderRequest {
  productId: string;
  quantity: number;
}

export interface GetOrdersParams {
  userId?: string;
  farmerId?: string;
  status?: OrderStatus;
  page?: number;
  limit?: number;
}

export interface OrdersResponse {
  orders: Order[];
  total: number;
  page: number;
  limit: number;
}

export interface UpdateOrderStatusRequest {
  status: OrderStatus;
}

const orderApi = {
  createOrder: (data: CreateOrderRequest) =>
    axiosInstance.post(`/orders`, data),

  getOrders: (params: GetOrdersParams) =>
    axiosInstance.get<OrdersResponse>(`/orders`, { params }),

  getOrderById: (id: string) => axiosInstance.get<Order>(`/orders/${id}`),

  updateOrderStatus: (id: string, data: UpdateOrderStatusRequest) =>
    axiosInstance.patch<Order>(`/orders/${id}`, data),
};

export default orderApi;
