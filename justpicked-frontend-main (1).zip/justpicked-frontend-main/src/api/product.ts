import axiosInstance from "config/axiosInstance";

interface ProductData {
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
  image?: File;
}

interface ProductQueryParams {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortType?: 'asc' | 'desc';
  search?: string;
}

export const products = {
  // Get all products with pagination and filters
  getAll: async (params: ProductQueryParams) => {
    try {
      const response = await axiosInstance.get("/products", { params });
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },
  // Get all products with pagination and filters
  getAllFarmer: async (params: ProductQueryParams) => {
    try {
      const response = await axiosInstance.get("/products/farmer", { params });
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },

  // Get a single product by slug
  getBySlug: async (slug: string) => {
    try {
      const response = await axiosInstance.get(`/products/${slug}`);
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },

  // Create a new product
  create: async (productData: ProductData) => {
    try {
      const formData = new FormData();
      Object.entries(productData).forEach(([key, value]) => {
        if (value !== undefined) {
          if (key === 'image' && value instanceof File) {
            formData.append(key, value);
          } else {
            formData.append(key, String(value));
          }
        }
      });

      const response = await axiosInstance.post("/products", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },

  // Update a product
  update: async (slug: string, productData: Partial<ProductData>) => {
    try {
      const formData = new FormData();
      Object.entries(productData).forEach(([key, value]) => {
        if (value !== undefined) {
          if (key === 'image' && value instanceof File) {
            formData.append(key, value);
          } else {
            formData.append(key, String(value));
          }
        }
      });

      const response = await axiosInstance.patch(`/products/${slug}`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },

  // Delete a product
  delete: async (slug: string) => {
    try {
      const response = await axiosInstance.delete(`/products/${slug}`);
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },
};
