import axiosInstance from "config/axiosInstance";

export const auth = {
  login: async (email: string, password: string) => {
    try {
      const response = await axiosInstance.post("/auth/login", {
        email,
        password,
      });
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },
  register: async (
    name: string,
    role: string,
    email: string,
    password: string,
    phone: string
  ) => {
    try {
      const response = await axiosInstance.post("/auth/register", {
        name,
        role,
        email,
        password,
        phone
      });
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },
};
