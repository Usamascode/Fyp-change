import axiosInstance from "config/axiosInstance";

export const inventory = {
  getAll: async (page: number, pageSize: number, query: string) => {
    try {
      let url = `/inventory?page=${page}&pageSize=${pageSize}`;
      if (query) {
        url += `&query=${query}`;
      }
      const response = await axiosInstance.get(url);
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },
  getJobs: async (page: number, pageSize: number) => {
    try {
      const response = await axiosInstance.get(
        `/inventory/pending-jobs?page=${page}&pageSize=${pageSize}`
      );
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },
  upload: async (data: FormData) => {
    try {
      const response = await axiosInstance.post(`/inventory/upload`, data);
      return response.data;
    } catch (error) {
      return Promise.reject(error);
    }
  },
};
