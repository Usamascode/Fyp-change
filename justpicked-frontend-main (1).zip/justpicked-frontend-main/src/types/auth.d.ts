export type User = {
    id: string;
    email: string;
    name: string | null;
    role: "ADMIN" | "USER" | "FARMER";
    isEmailVerified: boolean;
    createdAt: string;
    updatedAt: string;
};

export type Token = {
    token: string;
    expires: string;
};


export type Tokens = {
    access: Token;
    refresh: Token;
};


export type AuthLoginResponse = {
    user: User;
    tokens: Tokens;
};