export type Inventory = {
  id: string;
  ean: string;
  ISBN: string;
  price: string;
  quantity: string;
  discount: string;
  sellerPrice: string;
  createdAt: string;
  updatedAt: string;
};

export type Job = {
  id: number
  type: JobType
  status: JobStatus
  filePath: string
  createdAt: Date
  updatedAt: Date
}
