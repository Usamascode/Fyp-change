// authStore.ts
import { api } from 'api';
import { AuthLoginResponse, User } from 'types/auth';
import { create } from 'zustand';

interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;

}

export const useAuthStore = create<AuthState>((set) => ({
  isAuthenticated: !!localStorage.getItem('authToken'),
  user: JSON.parse(localStorage.getItem('user') || '{}') as User,
  login: async (email, password) => {
    const response: AuthLoginResponse = await api.auth.login(email, password);
    if (response?.user) {
      localStorage.setItem('authToken', response.tokens.access.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      set({
        isAuthenticated: true,
        user: response.user,
      });
    }
  },
  logout: () => {
    localStorage.removeItem('authToken');
    set({ isAuthenticated: false, user: null });
  }
}));
