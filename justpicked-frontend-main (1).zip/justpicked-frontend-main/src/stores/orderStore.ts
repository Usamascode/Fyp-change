import { create } from 'zustand';
import { toast } from 'react-toastify';
import orderApi, { Order, CreateOrderRequest, GetOrdersParams, OrdersResponse } from '../api/order';

interface OrderState {
  orders: Order[];
  currentOrder: Order | null;
  isLoading: boolean;
  error: string | null;
  totalPages: number;
  currentPage: number;
  createOrder: (data: CreateOrderRequest) => Promise<void>;
  getOrders: (params: GetOrdersParams) => Promise<OrdersResponse>;
  getOrderById: (id: string) => Promise<void>;
  updateOrderStatus: (id: string, status: string) => Promise<void>;
}

export const useOrderStore = create<OrderState>((set, get) => ({
  orders: [],
  currentOrder: null,
  isLoading: false,
  error: null,
  totalPages: 0,
  currentPage: 1,

  createOrder: async (data: CreateOrderRequest) => {
    try {
      set({ isLoading: true, error: null });
      const response = await orderApi.createOrder(data);
      set((state) => ({
        orders: [...state.orders, response.data],
        isLoading: false,
      }));
      toast.success('Order created successfully');
    } catch (error) {
      set({ error: 'Failed to create order', isLoading: false });
      toast.error('Failed to create order');
      throw error;
    }
  },

  getOrders: async (params: GetOrdersParams) => {
    try {
      set({ isLoading: true, error: null });
      const response = await orderApi.getOrders(params);
      set({
        orders: response.data.orders,
        totalPages: Math.ceil(response.data.total / (params.limit || 10)),
        currentPage: params.page || 1,
        isLoading: false,
      });
      return response.data;
    } catch (error) {
      set({ error: 'Failed to fetch orders', isLoading: false });
      toast.error('Failed to fetch orders');
      throw error;
    }
  },

  getOrderById: async (id: string) => {
    try {
      set({ isLoading: true, error: null });
      const response = await orderApi.getOrderById(id);
      set({ currentOrder: response.data, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch order details', isLoading: false });
      toast.error('Failed to fetch order details');
      throw error;
    }
  },

  updateOrderStatus: async (id: string, status: any) => {
    try {
      set({ isLoading: true, error: null });
      const response = await orderApi.updateOrderStatus(id, { status });
      set((state) => ({
        orders: state.orders.map((order) =>
          order.id === id ? response.data : order
        ),
        currentOrder: state.currentOrder?.id === id ? response.data : state.currentOrder,
        isLoading: false,
      }));
      toast.success('Order status updated successfully');
    } catch (error) {
      set({ error: 'Failed to update order status', isLoading: false });
      toast.error('Failed to update order status');
      throw error;
    }
  },
})); 