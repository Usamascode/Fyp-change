import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  FaCloudSun,
  FaBox,
  FaShoppingCart,
  FaMoneyBillWave,
  FaMapMarkerAlt,
} from "react-icons/fa";
import { useAuthStore } from "../../stores/authStore";
import {
  getWeatherByLocation,
  getUserLocation,
  WeatherData as WeatherServiceData,
} from "../../services/weatherService";

interface WeatherData {
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  forecast: {
    date: string;
    temperature: number;
    condition: string;
  }[];
}

interface DashboardStats {
  totalProducts: number;
  activeOrders: number;
  totalRevenue: number;
}

const FarmerDashboardPage = () => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [stats, setStats] = useState<DashboardStats>({
    totalProducts: 0,
    activeOrders: 0,
    totalRevenue: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [locationPermissionDenied, setLocationPermissionDenied] =
    useState(false);
  const { user } = useAuthStore();

  const fetchWeatherAndStats = async () => {
    try {
      setIsLoading(true);
      setError(null);
      setLocationPermissionDenied(false);

      // Get user location
      const location = await getUserLocation();
      console.log("User location:", location);

      // Get weather data from the service
      const weatherData = await getWeatherByLocation(
        location.lat,
        location.lon
      );
      console.log("Weather data received:", weatherData);

      // Transform the weather data to match our component's interface
      const transformedWeather: WeatherData = {
        temperature: weatherData.currentWeather.temperature,
        condition: weatherData.currentWeather.condition,
        humidity: weatherData.currentWeather.humidity,
        windSpeed: weatherData.currentWeather.windSpeed,
        forecast: weatherData.forecast.map((day) => ({
          date: day.date,
          temperature: day.temperature,
          condition: day.condition,
        })),
      };

      setWeather(transformedWeather);

      // Mock stats data (replace with actual API call when available)
      const mockStats = {
        totalProducts: 45,
        activeOrders: 12,
        totalRevenue: 2500,
      };

      setStats(mockStats);
    } catch (error: any) {
      console.error("Error fetching dashboard data:", error);

      // Check if the error is due to location permission being denied
      // if (error instanceof Error) {
      console.log(error)
        const errorMessage = error.message;
        if (errorMessage === "User denied Geolocation") {
          setLocationPermissionDenied(true);
          setWeather(null);
          return; // Exit early to prevent setting the generic error
        }
      // }

      // For any other error, show the generic error message
      setError("Failed to load dashboard data. Please try again later.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchWeatherAndStats();
  }, []);

  const handleRequestLocationPermission = () => {
    // This will trigger the browser's location permission prompt
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          // If permission is granted, fetch weather data using the obtained coordinates
          const weatherData = await getWeatherByLocation(
            position.coords.latitude,
            position.coords.longitude
          );
          
          // Transform the weather data to match our component's interface
          const transformedWeather: WeatherData = {
            temperature: weatherData.currentWeather.temperature,
            condition: weatherData.currentWeather.condition,
            humidity: weatherData.currentWeather.humidity,
            windSpeed: weatherData.currentWeather.windSpeed,
            forecast: weatherData.forecast.map(day => ({
              date: day.date,
              temperature: day.temperature,
              condition: day.condition
            }))
          };
          
          setWeather(transformedWeather);
          setLocationPermissionDenied(false);
        } catch (error) {
          console.error("Error fetching weather data:", error);
          setError("Failed to load weather data. Please try again later.");
        }
      },
      (error) => {
        console.error("Location permission error:", error);
        setLocationPermissionDenied(true);
        setWeather(null);
      }
    );
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "clear":
        return "☀️";
      case "clouds":
        return "☁️";
      case "rain":
        return "🌧️";
      case "snow":
        return "❄️";
      case "thunderstorm":
        return "⛈️";
      case "drizzle":
        return "🌦️";
      case "mist":
      case "fog":
        return "🌫️";
      case "sunny":
        return "☀️";
      case "partly cloudy":
        return "⛅";
      case "cloudy":
        return "☁️";
      case "light rain":
        return "🌦️";
      default:
        return "☀️";
    }
  };

  const formatDate = (dateString: string) => {
    // If the date is already in the format we want (e.g., "Mon", "Tue"), just return it
    if (dateString.length <= 3) {
      return dateString;
    }

    // Otherwise, try to parse it
    try {
      const date = new Date(dateString);
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      if (
        dateString === today.toLocaleDateString("en-US", { weekday: "short" })
      ) {
        return "Today";
      } else if (
        dateString ===
        tomorrow.toLocaleDateString("en-US", { weekday: "short" })
      ) {
        return "Tomorrow";
      } else {
        return dateString;
      }
    } catch (e) {
      // If parsing fails, just return the original string
      return dateString;
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-center text-red-500">
          <p className="text-lg font-medium">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 rounded-lg bg-green-500 px-4 py-2 text-white hover:bg-green-600"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>

      {/* Weather Card */}
      <div className="rounded-lg bg-white p-6 shadow">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-medium text-gray-900">
              Weather Forecast
            </h2>
            <p className="text-sm text-gray-500">Current weather conditions</p>
          </div>
          <FaCloudSun className="h-8 w-8 text-yellow-500" />
        </div>

        {locationPermissionDenied ? (
          <div className="mt-8 text-center">
            <FaMapMarkerAlt className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-lg font-medium text-gray-900">
              Location Access Required
            </h3>
            <p className="mt-1 text-sm text-gray-500">
              Please enable location access to get weather forecast for your
              area.
            </p>
            <button
              onClick={handleRequestLocationPermission}
              className="mt-4 rounded-lg bg-green-500 px-4 py-2 text-white hover:bg-green-600"
            >
              Enable Location Access
            </button>
          </div>
        ) : weather ? (
          <>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <p className="text-3xl font-bold text-gray-900">
                  {weather.temperature}°C
                </p>
                <p className="text-gray-600">{weather.condition}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-gray-600">
                  Humidity: {weather.humidity}%
                </p>
                <p className="text-sm text-gray-600">
                  Wind Speed: {weather.windSpeed} km/h
                </p>
              </div>
            </div>

            {/* 5-Day Forecast */}
            <div className="mt-6">
              <h3 className="mb-3 text-sm font-medium text-gray-900">
                5-Day Forecast
              </h3>
              <div className="grid grid-cols-5 gap-4">
                {weather.forecast.map((day, index) => (
                  <div
                    key={index}
                    className="rounded-lg bg-gray-50 p-3 text-center"
                  >
                    <p className="text-sm text-gray-500">
                      {formatDate(day.date)}
                    </p>
                    <p className="my-1 text-2xl">
                      {getWeatherIcon(day.condition)}
                    </p>
                    <p className="text-sm font-medium text-gray-900">
                      {day.temperature}°C
                    </p>
                    <p className="text-xs text-gray-500">{day.condition}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
};

export default FarmerDashboardPage;
