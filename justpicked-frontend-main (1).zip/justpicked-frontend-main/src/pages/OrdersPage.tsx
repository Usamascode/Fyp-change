import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FaShoppingBag, FaArrowLeft } from 'react-icons/fa';
import { useOrderStore } from '../stores/orderStore';
import { useAuthStore } from '../stores/authStore';

const OrdersPage = () => {
  const navigate = useNavigate();
  const { orders, isLoading, getOrders, currentPage, totalPages } = useOrderStore();
  const { user } = useAuthStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [totalOrders, setTotalOrders] = useState(0);

  useEffect(() => {
    if (user) {
      fetchOrders(1);
    }
  }, [user]);

  const fetchOrders = async (page: number) => {
    try {
      const response = await getOrders({
        page,
        limit: 10
      });
      
      // Update total orders from the API response
      if (response && response.total) {
        setTotalOrders(response.total);
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  const handlePageChange = (page: number) => {
    fetchOrders(page);
  };

  const filteredOrders = orders.filter(order =>
    order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-32 w-32 animate-spin rounded-full border-b-2 border-t-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-green-500 hover:text-green-600"
        >
          <FaArrowLeft className="mr-2" />
          Back
        </button>
        <h1 className="text-2xl font-bold text-gray-800">My Orders</h1>
        <div className="w-24"></div>
      </div>

      <div className="mb-6">
        <input
          type="text"
          placeholder="Search orders..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full rounded-lg border border-gray-300 px-4 py-2 focus:border-green-500 focus:outline-none"
        />
      </div>

      {filteredOrders.length === 0 ? (
        <div className="rounded-lg bg-white p-8 text-center shadow-md">
          <FaShoppingBag className="mx-auto mb-4 h-12 w-12 text-gray-400" />
          <h2 className="mb-2 text-xl font-semibold text-gray-800">No Orders Found</h2>
          <p className="text-gray-600">You haven't placed any orders yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-lg bg-white p-6 shadow-md"
            >
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Order #{order.id.slice(-6)}</h3>
                  <p className="text-sm text-gray-600">
                    {new Date(order.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <span className={`rounded-full px-3 py-1 text-sm font-medium ${
                  order.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                  order.status === 'DELIVERED' ? 'bg-green-100 text-green-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {order.status}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img
                      src={order.product.imageUrl}
                      alt={order.product.name}
                      className="h-12 w-12 rounded-lg object-cover"
                    />
                    <div className="ml-4">
                      <h4 className="font-medium text-gray-800">{order.product.name}</h4>
                      <p className="text-sm text-gray-600">Quantity: {order.quantity}</p>
                    </div>
                  </div>
                  <p className="font-medium text-gray-800">
                    PKR {(parseFloat(order.product.price) * order.quantity).toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="mt-4 border-t border-gray-200 pt-4">
                <div className="flex justify-between">
                  <span className="font-medium text-gray-800">Total Amount</span>
                  <span className="font-bold text-green-600">
                    PKR {parseFloat(order.totalPrice).toFixed(2)}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {totalOrders > 10 && (
        <div className="mt-8 flex justify-center space-x-2">
          {Array.from({ length: Math.ceil(totalOrders / 10) }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => handlePageChange(page)}
              className={`rounded-lg px-4 py-2 ${
                currentPage === page
                  ? 'bg-green-500 text-white'
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              {page}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrdersPage; 