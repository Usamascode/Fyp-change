import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { FaShoppingCart, FaChevronLeft, FaChevronRight } from "react-icons/fa";
import { products } from "api/product";
import { toast } from "react-toastify";
import { PiPlantFill } from "react-icons/pi";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
  imageUrl: string;
  slug: string;
}

const LandingPage = () => {
  const [productsList, setProductsList] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalProducts, setTotalProducts] = useState(0);

  useEffect(() => {
    fetchProducts();
  }, [currentPage]);

  const fetchProducts = async () => {
    try {
      setIsLoading(true);
      const response = await products.getAll({
        page: currentPage,
        limit: 8, // Show 8 products per page
      });

      setProductsList(response.products);
      setTotalProducts(response.total);
      setTotalPages(response.totalPages);
    } catch (error) {
      console.error("Error fetching products:", error);
      toast.error("Failed to fetch products. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative h-screen">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.pexels.com/photos/33786608/pexels-photo-33786608.jpeg')"
          }}
        >
          <div className="bg-black/20 absolute inset-0" />
        </div>
        <div className="relative mx-auto flex h-full max-w-7xl items-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl text-white"
          >
            <h1 className="mb-6 text-5xl xl:text-8xl font-bold leading-tight">
              Fresh Picked Direct from Local Farmers
            </h1>
            <p className="mb-8 text-xl">
              Connect with local farmers, get fresh produce delivered to your
              doorstep, and support sustainable agriculture.
            </p>
            <Link
              to="/register/customer"
              className="inline-block rounded-full bg-yellow-500 px-8 py-3 text-lg font-semibold text-zinc-900 transition hover:bg-green-600"
            >
              Get Started
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12 text-center text-3xl font-bold text-gray-800"
          >
            Featured Products
          </motion.h2>
          
          {isLoading ? (
            <div className="flex h-64 items-center justify-center">
              <div className="h-12 w-12 animate-spin rounded-full border-b-2 border-gray-900"></div>
            </div>
          ) : productsList.length === 0 ? (
            <div className="text-center text-gray-500">
              <p>No products available at the moment.</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
                {productsList.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="overflow-hidden rounded-xl bg-white shadow-lg transition hover:shadow-xl"
                  >
                    <Link to={`/products/${product.slug}`} className="block">
                      <img
                        src={product.imageUrl || "https://via.placeholder.com/300x200?text=No+Image"}
                        alt={product.name}
                        className="h-48 w-full object-cover"
                      />
                      <div className="p-6">
                        <h3 className="mb-2 text-xl font-semibold text-gray-800">
                          {product.name}
                        </h3>
                        <p className="mb-4 text-gray-600">{product.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-zinc-500">
                            PKR {product.price}
                          </span>
                          <button className="rounded-full bg-yellow-500 p-2 text-white transition hover:bg-green-600">
                            <FaShoppingCart className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-12 flex items-center justify-center">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handlePageChange(currentPage - 1)}
                      disabled={currentPage === 1}
                      className="flex h-10 w-10 items-center justify-center rounded-full border border-gray-300 bg-white text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                    >
                      <FaChevronLeft />
                    </button>
                    <span className="text-gray-700">
                      Page {currentPage} of {totalPages}
                    </span>
                    <button
                      onClick={() => handlePageChange(currentPage + 1)}
                      disabled={currentPage === totalPages}
                      className="flex h-10 w-10 items-center justify-center rounded-full border border-gray-300 bg-white text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                    >
                      <FaChevronRight />
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-900 text-white">
        <div className="mx-auto max-w-7xl px-4 py-12">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
            <div>
              <div className="mb-4 flex items-center gap-2">
                <PiPlantFill className="h-6 w-6 text-green-500" />
                <span className="text-xl font-bold">JustPicked</span>
              </div>
              <p className="text-gray-400">
                Connecting local farmers with customers for fresh, sustainable
                produce.
              </p>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-semibold">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/about" className="text-gray-400 hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/products"
                    className="text-gray-400 hover:text-white"
                  >
                    Products
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="text-gray-400 hover:text-white"
                  >
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-semibold">For Farmers</h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/register/farmer"
                    className="text-gray-400 hover:text-white"
                  >
                    Register as Farmer
                  </Link>
                </li>
                <li>
                  <Link
                    to="/farmer"
                    className="text-gray-400 hover:text-white"
                  >
                    Farmer Dashboard
                  </Link>
                </li>
                <li>
                  <Link
                    to="/pricing"
                    className="text-gray-400 hover:text-white"
                  >
                    Pricing
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-semibold">For Customers</h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/register/customer"
                    className="text-gray-400 hover:text-white"
                  >
                    Register as Customer
                  </Link>
                </li>
                <li>
                  <Link
                    to="/orders"
                    className="text-gray-400 hover:text-white"
                  >
                    My Orders
                  </Link>
                </li>
                <li>
                  <Link to="/faq" className="text-gray-400 hover:text-white">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>
              &copy; {new Date().getFullYear()} JustPicked. All rights
              reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
