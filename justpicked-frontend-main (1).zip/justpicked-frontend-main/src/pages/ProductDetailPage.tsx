import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  FaShoppingCart,
  FaArrowLeft,
  FaMinus,
  FaPlus,
} from "react-icons/fa";
import { products } from "api/product";
import { toast } from "react-toastify";
import { useOrderStore } from "../stores/orderStore";
import { useAuthStore } from "../stores/authStore";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
  imageUrl: string;
  slug: string;
  farmer: {
    id: string;
    name: string;
  };
}

const ProductDetailPage = () => {
  const { productId } = useParams<{ productId: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [isOrdering, setIsOrdering] = useState(false);
  const { createOrder } = useOrderStore();
  const { user } = useAuthStore();

  useEffect(() => {
    if (productId) {
      fetchProduct(productId);
    }
  }, [productId]);

  const fetchProduct = async (slug: string) => {
    try {
      setLoading(true);
      const data = await products.getBySlug(slug);
      setProduct(data);
    } catch (error) {
      console.error("Error fetching product:", error);
      toast.error("Failed to load product details. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleQuantityChange = (change: number) => {
    if (!product) return;

    const newQuantity = quantity + change;
    if (newQuantity >= 1 && newQuantity <= product.stock) {
      setQuantity(newQuantity);
    }
  };

  const handleOrderNow = async () => {
    if (!product) return;
    setIsOrdering(true);
    if (!user) {
      toast.error("Please login to place an order");
      navigate("/login");
      return;
    }

    try {
      await createOrder({
        productId: product.id,
        quantity: quantity,
      });
      // navigate("/orders");
    } catch (error) {
      console.error("Error placing order:", error);
      toast.error("Failed to place order. Please try again.");
    } finally {
      setIsOrdering(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="border-t-transparent h-12 w-12 animate-spin rounded-full border-4 border-green-500"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-zinc-50 py-8">
        <div className="mx-auto max-w-6xl px-4">
          <button
            onClick={() => navigate(-1)}
            className="mb-6 flex items-center text-zinc-600 hover:text-green-500"
          >
            <FaArrowLeft className="mr-2" /> Back to Products
          </button>
          <div className="rounded-xl bg-white p-8 text-center shadow-md">
            <h2 className="text-2xl font-bold text-zinc-800">
              Product Not Found
            </h2>
            <p className="mt-2 text-zinc-600">
              The product you're looking for doesn't exist or has been removed.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50 py-8">
      <div className="mx-auto max-w-6xl px-4">
        <button
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center text-zinc-600 hover:text-green-500"
        >
          <FaArrowLeft className="mr-2" /> Back to Products
        </button>

        <div className="grid gap-8 md:grid-cols-2">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="overflow-hidden border-none rounded-xl p-4"
          >
            <img
              src={
                product.imageUrl ||
                "https://via.placeholder.com/600x400?text=No+Image"
              }
              alt={product.name}
              className="h-full w-full object-cover rounded-xl"
            />
          </motion.div>

          {/* Product Details */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="rounded-xl bg-white p-6 backdrop-blur-2xl shadow-sm"
          >
            <div className="mb-4 flex items-center justify-between">
              <h1 className="text-3xl font-bold text-zinc-800">
                {product.name}
              </h1>
              <span className="rounded-full bg-green-100 px-3 py-1 text-sm font-medium text-green-800">
                {product.category}
              </span>
            </div>

            <div className="mb-6">
              <p className="text-3xl font-bold text-green-600">
                PKR {product.price}
              </p>
            </div>

            <div className="mb-6">
              <h2 className="mb-2 text-lg font-semibold text-zinc-800">
                Description
              </h2>
              <p className="text-zinc-600">{product.description}</p>
            </div>

            <div className="mb-6 grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-zinc-500">Farmer</h3>
                <p className="text-zinc-800">{product.farmer.name}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-zinc-500">Stock</h3>
                <p className="text-zinc-800">{product.stock} available</p>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="mb-2 text-sm font-medium text-zinc-500">
                Quantity
              </h3>
              <div className="flex items-center">
                <button
                  onClick={() => handleQuantityChange(-1)}
                  className="flex h-10 w-10 items-center justify-center rounded-l-lg border border-zinc-300 bg-white text-zinc-600 hover:bg-zinc-100"
                >
                  <FaMinus />
                </button>
                <input
                  type="number"
                  min="1"
                  max={product.stock}
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                  className="h-10 w-16 border-y border-zinc-300 bg-white text-center text-zinc-800 focus:outline-none"
                />
                <button
                  onClick={() => handleQuantityChange(1)}
                  className="flex h-10 w-10 items-center justify-center rounded-r-lg border border-zinc-300 bg-white text-zinc-600 hover:bg-zinc-100"
                >
                  <FaPlus />
                </button>
              </div>
            </div>

            <button
              onClick={handleOrderNow}
              disabled={isOrdering}
              className="flex w-full items-center justify-center rounded-lg bg-yellow-500 px-6 py-3 text-zinc-900 transition hover:bg-yellow-700"
            >
              <FaShoppingCart className="mr-2" />
              {isOrdering ? "Placing Order..." : "Order Now"}
            </button>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
